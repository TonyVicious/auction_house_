from flask import Flask, render_template, request, redirect
from flask_restful import Api, Resource, reqparse, abort, fields, marshal_with
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__, template_folder='templates')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
api = Api(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)

db.create_all()


class UserModel(db.Model):
      id = db.Column(db.Integer, primary_key=True)
      name = db.Column(db.String(100), nullable=False)
      surname = db.Column(db.String(100), nullable=False)
      age = db.Column(db.Integer, nullable=False)

      def __repr__(self):
        return f"User(name={self.name}, surname={self.surname}, age={self.age})"
      
user_put_args = reqparse.RequestParser()
user_put_args.add_argument("name", type=str, help="Name of user", required=True)
user_put_args.add_argument("surname", type=str, help="Surname of user", required=True)
user_put_args.add_argument("age", type=int, help="Age of user", required=True)

user_update_args = reqparse.RequestParser()
user_update_args.add_argument("name", type=str, help="Name of user")
user_update_args.add_argument("surname", type=str, help="Surname of user")
user_update_args.add_argument("age", type=int, help="Age of user")




resource_fields = {
    'id' : fields.Integer,
    'name' : fields.String,
    'surname' : fields.String,
    'age' : fields.Integer
}


class User(Resource):
    @marshal_with(resource_fields)
    def get(self, user_id):
        result = UserModel.query.filter_by(id=user_id).first()
        if not result:
            abort(404, message="User not found")
        return result, 200
    
    @marshal_with(resource_fields)
    def post(self, user_id):
        args = user_put_args.parse_args()
        result = UserModel.query.filter_by(id=user_id).first()
        if result:
            abort(409, message="User already exists")
        user = UserModel(id=user_id, name=args['name'], surname=args['surname'], age=args['age'])
        db.session.add(user)
        db.session.commit()
        return user, 201
    
    @marshal_with(resource_fields)
    def patch(self, user_id):
        args = user_update_args.parse_args()
        result = UserModel.query.filter_by(id=user_id).first()
        if not result:
            abort(404, message="User not found")
        if args["name"]:
            result.name = args['name']
        if args["surname"]:
            result.surname = args['surname']
        if args["age"]:
            result.age = args['age']              
        db.session.commit()
        return result, 200
    
    @marshal_with(resource_fields)
    def delete(self, user_id):
        result = UserModel.query.filter_by(id=user_id).first()
        if not result:
            abort(404, message="User not found")
        db.session.delete(result)
        db.session.commit()
        return {"message": "User deleted"}, 200
          

    
    
api.add_resource(User, "/users/<int:user_id>")

@app.route('/')
def index():
    users = UserModel.query.all()
    return render_template('index.html', users=users)

    
@app.route('/add', methods=['POST'])
def add_user():
    name = request.form['name']
    surname = request.form['surname']
    age = int(request.form['age'])

    user = UserModel(name=name, surname=surname, age=age)
    db.session.add(user)
    db.session.commit()

    return redirect('/')


@app.route('/update', methods=['POST'])
def update_user():
    user_id = int(request.form['user_id'])
    name = request.form['name']
    surname = request.form['surname']
    age = int(request.form['age'])

    user = UserModel.query.get(user_id)
    if not user:
        abort(404, message="User not found")

    user.name = name
    user.surname = surname
    user.age = age

    db.session.commit()

    return redirect('/')


@app.route('/delete', methods=['POST'])
def delete_user():
    user_id = int(request.form['user_id'])

    user = UserModel.query.get(user_id)
    if not user:
        abort(404, message="User not found")

    db.session.delete(user)
    db.session.commit()

    return redirect('/')


if __name__ == '__main__':
    app.run(port=5500)
