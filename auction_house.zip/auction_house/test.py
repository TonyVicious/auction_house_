import requests

# Assuming your Flask server is running locally on http://localhost:5000

# Base URL for your API
base_url = 'http://127.0.0.1:5000'

# Test data for creating users
test_users = [
    {"user_id": 1, "name": "John", "surname": "Doe", "age": 25},
    {"user_id": 2, "name": "Jane", "surname": "Smith", "age": 30},
    {"user_id": 3, "name": "Alice", "surname": "Johnson", "age": 27},
    {"user_id": 4, "name": "Bob", "surname": "Brown", "age": 32},
    {"user_id": 5, "name": "Emily", "surname": "Davis", "age": 29},
    {"user_id": 6, "name": "Michael", "surname": "Wilson", "age": 35},
    {"user_id": 7, "name": "Olivia", "surname": "Taylor", "age": 28},
    {"user_id": 8, "name": "Daniel", "surname": "Anderson", "age": 31},
    {"user_id": 9, "name": "Sophia", "surname": "Clark", "age": 26},
    {"user_id": 10, "name": "Matthew", "surname": "White", "age": 33}
]

# Endpoint for creating users
endpoint = '/users/'

# Loop through the test users and send a POST request to create each user
for user in test_users:
    user_id = user['user_id']
    response = requests.post(f"{base_url}{endpoint}{user_id}", json=user)
    if response.status_code == 201:
        print(f"User created: {user}")
    else:
        print(f"Failed to create user: {user}")
